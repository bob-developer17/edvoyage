//Avatar

String companylogo = "assets/logo.png";
String onboarding1 = "assets/screen1.png";
String onboarding2 = "assets/screen2.png";
String onboarding3 = "assets/screen3.png";
String onboarding4 = "assets/screen4.png";
String login = "assets/Login.png";
String forgot = "assets/forgot.png";
String otp = "assets/otp.png";
String reset = "assets/reset.png";
String signup = "assets/signup.png";
String booked = "assets/booked.png";
String overseas1 = "assets/overseas1.png";
String oralCavity = "assets/oral_cavity.png";
String background = "assets/background.png";
String google = "assets/google.jpeg";
String slotbooked = "assets/slotbooked.png";
String universityimage = "assets/Vector_(12).png";
String coursesimage = "assets/Vector (13).png";
String undergraduate = "assets/Vector_(18).png";
String fmeg = "assets/badge_1_(3).png";
String usml = "assets/badge 1 (2).png";
String plab = "assets/badge 1 (1).png";
String soon = "assets/soon.png";
String edvoyagelogo1 = "assets/edvoyage1.png";
