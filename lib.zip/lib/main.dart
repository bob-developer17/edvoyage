import 'package:flutter/material.dart';
import 'package:frontend/screens/final_ui/1/1.dart';

import 'package:frontend/utils/BottomNavigation/bottom_navigation.dart';
import 'package:frontend/utils/colors/colors.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(body: NotesSection()),
    );
  }
}
