import 'package:flutter/material.dart';

class CustomRedSquare extends StatefulWidget {
  @override
  State<CustomRedSquare> createState() => _CustomRedSquareState();
}

class _CustomRedSquareState extends State<CustomRedSquare> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Image.asset(
      'assets/profile_main.png',
      height: size.height * 0.30,
      width: size.width * 0.5,
    );
  }
}
