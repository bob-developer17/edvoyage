import 'package:flutter/material.dart';
import 'package:frontend/screens/profile/appbar.dart';

import 'button.dart';
import 'form.dart';
import 'image.dart';

class profilescreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: CustomAppBar(),
      body: SingleChildScrollView(
        child: Container(
          height: screenSize.height,
          width: screenSize.width,
          padding: EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomRedSquare(),
                ],
              ),
              SizedBox(height: 20),
              Divider(
                  color: const Color.fromARGB(255, 234, 230, 230),
                  thickness: 2),
              SizedBox(height: 20),
              ContactForm(),
              SizedBox(height: 20),
              Divider(
                  color: const Color.fromARGB(255, 230, 225, 225),
                  thickness: 2),
              CustomButtonWidget(buttonText: 'Verify profile'),
              CustomButtonWidget(buttonText: 'Reset Questions'),
            ],
          ),
        ),
      ),
    );
  }
}
