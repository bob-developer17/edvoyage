import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:frontend/screens/comingsoon.dart';
import 'package:frontend/screens/notesnew/homecard/card.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;

class teach_content_mcq extends StatefulWidget {
  @override
  State<teach_content_mcq> createState() => _NotesSectionState();
}

class _NotesSectionState extends State<teach_content_mcq> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Container(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start
            // there should be nos spacing bwteen 2 elements
            ,
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                'assets/teach_content/mcq/titleee.png',
                height: (size.height) * 0.09,
                width: size.width * 1,
              ),
              Image.asset(
                'assets/teach_content_video/1.png',
                height: (size.height) * 0.09,
                width: size.width,
              ),
              SizedBox(
                height: 20,
              ),
              Image.asset(
                'assets/teach_content_video/2.png',
                height: (size.height) * 0.09,
                width: size.width,
              ),
              SizedBox(
                height: 20,
              ),
              Image.asset(
                'assets/teach_content_video/3.png',
                height: (size.height) * 0.09,
                width: size.width,
              ),
              SizedBox(
                height: 20,
              ),
              Image.asset(
                'assets/teach_content_video/4.png',
                height: (size.height) * 0.09,
                width: size.width,
              ),
              SizedBox(
                height: 20,
              ),
              Image.asset(
                'assets/teach_content_video/5.png',
                height: (size.height) * 0.09,
                width: size.width,
              ),
              SizedBox(
                height: 20,
              ),
              Image.asset(
                'assets/teach_content_video/4.png',
                height: (size.height) * 0.09,
                width: size.width,
              ),
              SizedBox(
                height: 20,
              ),
              Image.asset(
                'assets/teach_content_video/5.png',
                height: (size.height) * 0.09,
                width: size.width,
              ),
            ]),
      ),
    );
  }
}
