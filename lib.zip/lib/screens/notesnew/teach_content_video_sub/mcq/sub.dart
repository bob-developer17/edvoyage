import 'package:flutter/material.dart';
import 'package:frontend/screens/notesnew/video_player/main.dart';

class TeachContentMCQSub extends StatefulWidget {
  const TeachContentMCQSub({super.key});

  @override
  State<TeachContentMCQSub> createState() => _TeachContentMCQSubState();
}

class _TeachContentMCQSubState extends State<TeachContentMCQSub> {
  final List<String> imagePaths = List.generate(
    10, // Generates 10 items (5 to 14)
    (index) => 'assets/teach_content/${index + 5}.png',
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset(
          'assets/logo_profile.png',
          width: 180,
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              const Text(
                "Book icon / Video / Human Anatomy",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              ListView.builder(
                shrinkWrap: true,
                physics:
                    const NeverScrollableScrollPhysics(), // To disable scrolling of ListView within SingleChildScrollView
                itemCount: imagePaths.length,
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => VideoScreen(),
                        ),
                      );
                    },
                    child: Column(
                      children: [
                        Image.asset(
                          imagePaths[index],
                          fit: BoxFit.cover,
                        ),
                        const SizedBox(height: 10), // Space between images
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
