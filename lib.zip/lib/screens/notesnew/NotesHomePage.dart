import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:frontend/screens/comingsoon.dart';
import 'package:frontend/screens/notesnew/homecard/card.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;

class NotesSection extends StatefulWidget {
  @override
  State<NotesSection> createState() => _NotesSectionState();
}

class _NotesSectionState extends State<NotesSection> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Container(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10.0),
            ),
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.asset(
                    'assets/book.png',
                    height: (size.height) * 0.03,
                    width: size.width * 0.1,
                  )
                ],
              ),
            ),
          ),
          SizedBox(height: 10),
          Image.asset(
            'assets/teach_content/1.png',
            height: (size.height) * 0.15,
            width: size.width,
          ),
          SizedBox(height: 10),
          Image.asset(
            'assets/teach_content/2.png',
            height: (size.height) * 0.15,
            width: size.width,
          ),
          SizedBox(height: 10),
          Image.asset(
            'assets/teach_content/3.png',
            height: (size.height) * 0.15,
            width: size.width,
          ),
          SizedBox(height: 10),
          Image.asset(
            'assets/teach_content/4.png',
            height: (size.height) * 0.15,
            width: size.width,
          ),
          SizedBox(height: 10),
          Image.asset(
            'assets/teach_content/4.png',
            height: (size.height) * 0.15,
            width: size.width,
          ),
        ]),
      ),
    );
  }
}
