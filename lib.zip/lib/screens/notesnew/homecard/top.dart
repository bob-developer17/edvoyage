import 'package:flutter/material.dart';
import 'package:frontend/screens/comingsoon.dart';
import 'package:frontend/screens/notesnew/homecard/lefttop.dart';
import 'package:frontend/utils/responsive.dart';

class TopWidget extends StatelessWidget {
  const TopWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return SizedBox(
        height: constraints.maxHeight * 0.5, // 50% of card height
        child: Row(
          mainAxisAlignment:
              MainAxisAlignment.spaceBetween, // Align left & right
          children: [
            // Video and Topics text
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [LeftTop(title: 'Video', subtitle: '23 Topics')],
            ),

            // Hamburger icon aligned to the right
            const Icon(
              Icons.menu, // Hamburger icon
              color: Colors.grey,
              size: 30,
            ),
          ],
        ),
      );
    });
  }
}
