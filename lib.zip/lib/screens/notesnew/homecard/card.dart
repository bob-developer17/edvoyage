import 'package:flutter/material.dart';
import 'top.dart';
import 'middle.dart';
import 'bottom.dart';

class card extends StatelessWidget {
  const card({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.grey[200], // Light grey background
        body: Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20), // Rounded corners
          ),
          elevation: 4, // Shadow effect
          color: Colors.white, // White background color
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                return SizedBox(
                    height: constraints.maxHeight * 0.5, // 50% of card height
                    child: TopWidget());
              }),
              // 50% height
              // 40% height
            ],
          ),
        ),
      ),
    );
  }
}
