import 'package:flutter/material.dart';

class BottomWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity, // Full width
      height: 2, // 10% of screen height
      color: Colors.green, // Fully filled green color
    );
  }
}
