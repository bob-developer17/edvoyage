import 'package:flutter/material.dart';

class MiddleWidget extends StatelessWidget {
  final String text;

  const MiddleWidget({
    Key? key,
    required this.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomRight, // Aligns text to the bottom-right
      child: Text(
        text,
        style: TextStyle(
          fontSize: MediaQuery.of(context).size.width * 0.05, // Responsive size
          fontWeight: FontWeight.bold,
          color: Colors.green, // Green text color
        ),
      ),
    );
  }
}
