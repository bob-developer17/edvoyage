import 'package:flutter/material.dart';

class clinical_case extends StatelessWidget {
  final List<String> imagePaths = List.generate(
    7,
    (index) =>
        'assets/teach_content_cs/main/${index == 7 ? '' : '${index + 1}'}.png',
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Center(
              child: Image.asset('assets/logo.png', height: 300, width: 300))),
      body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Image.asset(
                'assets/teach_content_cs/2.png',
              ),
              SizedBox(
                height: 10,
              ), // Static image at the top
              Expanded(
                child: ListView.builder(
                  itemCount: imagePaths.length,
                  itemBuilder: (context, index) {
                    return Column(
                      children: [
                        Image.asset(
                          imagePaths[index],
                          fit: BoxFit.cover,
                        ),
                        const SizedBox(height: 10), // Space between images
                      ],
                    );
                  },
                ),
              ),
            ],
          )),
    );
  }
}
