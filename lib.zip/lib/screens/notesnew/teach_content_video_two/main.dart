// a simple flutter screen with an appbar and a body both having images eachf rom asets

import 'package:flutter/material.dart';

class video_two extends StatefulWidget {
  @override
  State<video_two> createState() => _video_twoState();
}

class _video_twoState extends State<video_two> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Image.asset(
        'assets/logo.png',
        height: 200,
        width: double.infinity,
      )),
      body: ListView(
        children: [
          Image.asset(
            'assets/teach_content_video/middle.png',
          ),
          Image.asset(
            'assets/teach_content_video/1.png',
          ),
          Image.asset(
            'assets/teach_content_video/2.png',
          ),
          Image.asset(
            'assets/teach_content_video/3.png',
          ),
          Image.asset(
            'assets/teach_content_video/4.png',
          ),
          Image.asset(
            'assets/teach_content_video/5.png',
          ),
          Image.asset(
            'assets/teach_content_video/6.png',
          ),
          Image.asset(
            'assets/teach_content_video/7.png',
          ),
          Image.asset(
            'assets/teach_content_video/8.png',
          ),
          Image.asset(
            'assets/teach_content_video/9.png',
          ),
          Image.asset(
            'assets/teach_content_video/10.png',
          ),
          Image.asset(
            'assets/teach_content_video/11.png',
          ),
          Image.asset(
            'assets/teach_content_video/12.png',
          ),
        ],
      ),
    );
  }
}
