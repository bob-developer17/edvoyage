import 'package:flutter/material.dart';

class HumanAnatomy extends StatefulWidget {
  @override
  State<HumanAnatomy> createState() => _HumanAnatomyState();
}

class _HumanAnatomyState extends State<HumanAnatomy> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: SizedBox(
          width: 200,
          height: 200,
          child: Image.asset('assets/logo.png'), // Replace with your logo asset
        ),
      ),
      body: ListView(
        children: [
          Image.asset('assets/human_anotamy/Video Content Card-1.png',
              fit: BoxFit.cover),
          Image.asset('assets/human_anotamy/Video Content Card-2.png',
              fit: BoxFit.cover),
          Image.asset('assets/human_anotamy/Video Content Card-3.png',
              fit: BoxFit.cover),
          Image.asset('assets/human_anotamy/Video Content Card-4.png',
              fit: BoxFit.cover),
          Image.asset('assets/human_anotamy/Video Content Card-5.png',
              fit: BoxFit.cover),
          Image.asset('assets/human_anotamy/Video Content Card-6.png',
              fit: BoxFit.cover),
          Image.asset('assets/human_anotamy/Video Content Card-7.png',
              fit: BoxFit.cover),
          Image.asset('assets/human_anotamy/Video Content Card-8.png',
              fit: BoxFit.cover),
          Image.asset('assets/human_anotamy/Video Content Card-9.png',
              fit: BoxFit.cover),
        ],
      ),
    );
  }
}
