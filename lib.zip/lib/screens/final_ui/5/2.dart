// 1,2
// 4-11

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:frontend/screens/comingsoon.dart';

import 'package:frontend/screens/notesnew/homecard/card.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;

class five_two extends StatefulWidget {
  @override
  State<five_two> createState() => _NotesSectionState();
}

class _NotesSectionState extends State<five_two> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Container(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: ListView(
        children: [
          Image.asset(
            'assets/five/title.png',
            width: size.width,
            height: size.height * 0.06, // Adjusted title image height
            fit: BoxFit.fill,
          ),
          Image.asset(
            'assets/five/1.png',
            width: size.width,
            height: size.height * 0.77,
            fit: BoxFit.fill,
          ),
          Image.asset(
            'assets/five/2.png',
            width: size.width,
            height: size.height * 0.09,
            fit: BoxFit.fill,
          )
        ],
      ),
    );
  }
}
