// 1,2
// 4-11

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:frontend/screens/comingsoon.dart';

import 'package:frontend/screens/final_ui/5/2.dart';
import 'package:frontend/screens/notesnew/homecard/card.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;

class clinical_case_two extends StatefulWidget {
  @override
  State<clinical_case_two> createState() => _NotesSectionState();
}

class _NotesSectionState extends State<clinical_case_two> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Container(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: SingleChildScrollView(
        child: ListView(
          physics: BouncingScrollPhysics(),
          shrinkWrap: true,
          padding: EdgeInsets.zero, // Ensures no extra spacing
          children: [
            Image.asset(
              'assets/teach_content_flash_card/two/2.png',
              width: size.width,
              height: size.height * 0.053, // Adjusted title image height
              fit: BoxFit.fill,
            ),
            SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  // five_two i need gesture detector with on tap navigator
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => five_two(),
                        ),
                      );
                    },
                    child: Image.asset(
                      'assets/teach_content_flash_card/cards/1.png',
                      width: size.width,
                      height: size.height * 0.095,
                      fit: BoxFit.fill,
                    ),
                  ),

                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/2.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/3.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/4.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/5.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/6.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/7.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/8.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/9.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/10.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/11.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/12.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/13.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/14.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/15.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/16.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/17.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/18.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 20),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/19.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/20.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 20),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/21.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  SizedBox(height: 25),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/22.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                  Image.asset(
                    'assets/teach_content_flash_card/cards/23.png',
                    width: size.width,
                    height: size.height * 0.095,
                    fit: BoxFit.fill,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
