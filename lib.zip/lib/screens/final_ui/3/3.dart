import 'package:flutter/material.dart';

class gametogenesis extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    double tmargin = screenHeight * 0.9; // 10% of screen width as margin
    double bmargin = screenHeight * 0.1; // 10% of screen height as margin

    return Stack(
      alignment: Alignment.center,
      children: [
        // Main Image
        Image.asset(
          'assets/gametogenesis/main.png',
        ),

        // Left Image
        Positioned(
          bottom: screenWidth * 0.05, // Adjust position as needed
          left: bmargin * 0.5, // Responsive margin
          child: Image.asset(
            'assets/gametogenesis/left.png',
            width: screenWidth * 0.2, // Make size responsive
          ),
        ),

        // Right Image
        Positioned(
          bottom: screenWidth * 0.05, // Adjust position as needed
          right: bmargin * 0.5, // Responsive margin
          child: Image.asset(
            'assets/gametogenesis/right.png',
            width: screenWidth * 0.2, // Make size responsive
          ),
        ),

        // Floating Button (Optional)
      ],
    );
  }
}
