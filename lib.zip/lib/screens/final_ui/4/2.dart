// 1,2
// 4-11

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:frontend/screens/comingsoon.dart';

import 'package:frontend/screens/notesnew/homecard/card.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;

class clinical_case_two extends StatefulWidget {
  @override
  State<clinical_case_two> createState() => _NotesSectionState();
}

class _NotesSectionState extends State<clinical_case_two> {
  @override
  bool _isSecondImageVisible = true;
  bool _isThirdImageVisible = true;
  bool _isFourthImageVisible = true;
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Container(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: SingleChildScrollView(
        child: ListView(
          physics: BouncingScrollPhysics(),
          shrinkWrap: true,
          padding: EdgeInsets.zero, // Ensures no extra spacing
          children: [
            Image.asset(
              'assets/4/title.png',
              width: size.width,
              height: size.height * 0.06, // Adjusted title image height
              fit: BoxFit.fill,
            ),
            Image.asset(
              'assets/teach_content_cs/3.png',
              width: size.width,
              height: size.height * 0.27,
              fit: BoxFit.fill,
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  _isSecondImageVisible =
                      !_isSecondImageVisible; // Toggle visibility
                });
              },
              child: Image.asset(
                'assets/teach_content_cs/4.png',
                width: size.width,
                height: size.height * 0.07,
                fit: BoxFit.fill,
              ),
            ),
            Visibility(
              visible: _isSecondImageVisible,
              child: Image.asset(
                'assets/teach_content_cs/three/sub.png',
                width: size.width,
                height: size.height * 0.3,
                fit: BoxFit.fill,
              ),
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  _isThirdImageVisible =
                      !_isThirdImageVisible; // Toggle visibility
                });
              },
              child: Image.asset(
                'assets/teach_content_cs/5.png',
                width: size.width,
                height: size.height * 0.07,
                fit: BoxFit.fill,
              ),
            ),
            Visibility(
              visible: _isThirdImageVisible,
              child: Image.asset(
                'assets/teach_content_cs/four/sub.png',
                width: size.width,
                height: size.height * 0.1,
                fit: BoxFit.fill,
              ),
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  _isFourthImageVisible =
                      !_isFourthImageVisible; // Toggle visibility
                });
              },
              child: Image.asset(
                'assets/teach_content_cs/6.png',
                width: size.width,
                height: size.height * 0.07,
                fit: BoxFit.fill,
              ),
            ),
            Visibility(
              visible: _isFourthImageVisible,
              child: Image.asset(
                'assets/teach_content_cs/five/sub.png',
                width: size.width,
                height: size.height * 0.45,
                fit: BoxFit.fill,
              ),
            ),
            Image.asset(
              'assets/teach_content_cs/7.png',
              width: size.width,
              height: size.height * 0.07,
              fit: BoxFit.fill,
            ),
            Image.asset(
              'assets/teach_content_cs/8.png',
              width: size.width,
              height: size.height * 0.07,
              fit: BoxFit.fill,
            ),
            Image.asset(
              'assets/teach_content_cs/9.png',
              width: size.width,
              height: size.height * 0.07,
              fit: BoxFit.fill,
            ),
            Image.asset(
              'assets/teach_content_cs/10.png',
              width: size.width,
              height: size.height * 0.07,
              fit: BoxFit.fill,
            ),
            Image.asset(
              'assets/teach_content_cs/11.png',
              width: size.width,
              height: size.height * 0.07,
              fit: BoxFit.fill,
            ),
            SizedBox(height: 20),
            Image.asset(
              'assets/teach_content_cs/12.png',
              width: size.width,
              height: size.height * 0.03,
              fit: BoxFit.fill,
            ),
            SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
