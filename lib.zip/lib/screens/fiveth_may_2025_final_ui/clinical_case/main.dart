import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:frontend/screens/comingsoon.dart';
import 'package:frontend/screens/notesnew/homecard/card.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;

class teach_content_video extends StatefulWidget {
  @override
  State<teach_content_video> createState() => _NotesSectionState();
}

class _NotesSectionState extends State<teach_content_video> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Container(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start
              // there should be nos spacing bwteen 2 elements
              ,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Image.asset(
                          'assets/book.png',
                          height: (size.height) * 0.03,
                          width: size.width * 0.1,
                        ),
                        Text(
                          "/ Clinical Case",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Poppins',
                              color: primaryColor),
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Image.asset(
                  'assets/teach_content_video/1.png',
                  height: (size.height) * 0.09,
                  width: size.width,
                ),
                SizedBox(
                  height: 20,
                ),
                Image.asset(
                  'assets/teach_content_video/2.png',
                  height: (size.height) * 0.09,
                  width: size.width,
                ),
                SizedBox(
                  height: 20,
                ),
                Image.asset(
                  'assets/teach_content_video/3.png',
                  height: (size.height) * 0.09,
                  width: size.width,
                ),
                SizedBox(
                  height: 20,
                ),
                Image.asset(
                  'assets/teach_content_video/4.png',
                  height: (size.height) * 0.09,
                  width: size.width,
                ),
                SizedBox(
                  height: 20,
                ),
                Image.asset(
                  'assets/teach_content_video/5.png',
                  height: (size.height) * 0.09,
                  width: size.width,
                ),
                SizedBox(
                  height: 20,
                ),
                Image.asset(
                  'assets/teach_content_video/4.png',
                  height: (size.height) * 0.09,
                  width: size.width,
                ),
                SizedBox(
                  height: 20,
                ),
                Image.asset(
                  'assets/teach_content_video/5.png',
                  height: (size.height) * 0.09,
                  width: size.width,
                ),
              ]),
        ),
      ),
    );
  }
}
