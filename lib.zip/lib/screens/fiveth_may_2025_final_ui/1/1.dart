import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:frontend/screens/comingsoon.dart';
import 'package:frontend/screens/final_ui/2/1.dart';
import 'package:frontend/screens/final_ui/3/1.dart';
import 'package:frontend/screens/final_ui/4/1.dart';
import 'package:frontend/screens/final_ui/5/1.dart';
import 'package:frontend/screens/notesnew/homecard/card.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;

class NotesSection extends StatefulWidget {
  @override
  State<NotesSection> createState() => _NotesSectionState();
}

class _NotesSectionState extends State<NotesSection> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: SizedBox(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(
            horizontal: 16.0), // Add horizontal padding for spacing
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Image.asset(
                    'assets/book.png',
                    height: (size.height) * 0.03,
                    width: size.width * 0.1,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 3),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          TeachContentVideoTwo()), // Replace with your widget
                );
              },
              child: Image.asset(
                'assets/teach_content/1.png',
                height: (size.height) * 0.20,
                width: double.infinity,
                fit: BoxFit.fitWidth,
              ),
            ),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          TeachContentVideoTwo()), // Replace with your widget
                );
              },
              child: Image.asset(
                'assets/teach_content/2.png',
                height: (size.height) * 0.20,
                width: double.infinity,
                fit: BoxFit.fitWidth,
              ),
            ),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          clinical_case_two()), // Replace with your widget
                );
              },
              child: Image.asset(
                'assets/teach_content/3.png',
                height: (size.height) * 0.20,
                width: double.infinity,
                fit: BoxFit.fitWidth,
              ),
            ),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          ComingSoon()), // Replace with your widget
                );
              },
              child: Image.asset(
                'assets/teach_content/4.png',
                height: (size.height) * 0.20,
                width: double.infinity,
                fit: BoxFit.fitWidth,
              ),
            ),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          clinical_case()), // Replace with your widget
                );
              },
              child: Image.asset(
                'assets/teach_content/4.png',
                height: (size.height) * 0.20,
                width: double.infinity,
                fit: BoxFit.fitWidth,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
