import 'package:flutter/material.dart';

class GametogenesisQuizPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // get the screen size
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4F7), // Light grayish background
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context); // Go back to the previous screen
          },
        ),
        title: const Text(
          'Gametogenesis',
          style: TextStyle(
            color: Color(0xFF2E7D32),
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: InkWell(
              onTap: () {
                // Handle close button action
                print('Close button tapped');
              },
              borderRadius: BorderRadius.circular(15),
              child: const CircleAvatar(
                backgroundColor: Color(0xFFDCE3E8), // Light gray circle
                radius: 15,
                child: Icon(
                  Icons.close,
                  color: Colors.grey,
                  size: 20,
                ),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'Which of these is a major difference between oogenesis and spermatogenesis?',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
                color: Colors.black87,
              ),
            ),
            SizedBox(
              height: screenHeight * 0.215,
            ),
            _buildAnswerOption(
              'A - Spermatogenesis leads to two sperm, while oogenesis leads to one egg.',
              () {
                // Handle option A selection
                print('Option A selected');
              },
            ),
            const SizedBox(height: 8),
            _buildAnswerOption(
              'B - Oogenesis leads to four eggs while spermatogenesis leads to eight sperm.',
              () {
                // Handle option B selection
                print('Option B selected');
              },
            ),
            const SizedBox(height: 8),
            _buildAnswerOption(
              'C - Spermatogenesis leads to four sperm, while oogenesis leads to one egg.',
              () {
                // Handle option C selection
                print('Option C selected');
              },
            ),
            const SizedBox(height: 8),
            _buildAnswerOption(
              'D - Oogenesis leads to two eggs while spermatogenesis leads to one sperm.',
              () {
                // Handle option D selection
                print('Option D selected');
              },
            ),
            const Spacer(), // Pushes the bottom bar to the bottom
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  ElevatedButton(
                    onPressed: () {
                      // Handle previous button action
                      print('Previous button tapped');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2E7D32), // Green color
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 12),
                      textStyle: const TextStyle(fontSize: 16),
                    ),
                    child: const Text(
                      'PREV',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const Text(
                    '1 / 20',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black87,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Handle next button action
                      print('Next button tapped');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2E7D32), // Green color
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 12),
                      textStyle: const TextStyle(fontSize: 16),
                    ),
                    child: const Text(
                      'NEXT',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnswerOption(String text, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border:
              Border.all(color: const Color(0xFFDCE3E8)), // Light gray border
        ),
        child: Text(
          text,
          style: const TextStyle(fontSize: 16, color: Colors.black87),
        ),
      ),
    );
  }
}
