import 'package:flutter/material.dart';
import 'package:frontend/screens/fiveth_may_2025_final_ui/mcq/last/optionbutton.dart';

class GametogenesisBody extends StatelessWidget {
  const GametogenesisBody({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Which of these is a major difference between oogenesis and spermatogenesis?',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          OptionButton(
              text:
                  'A - Spermatogenesis leads to two sperm, while oogenesis leads to one egg.'),
          OptionButton(
              text:
                  'B - Oogenesis leads to four eggs while spermatogenesis leads to eight sperm.'),
          OptionButton(
              text:
                  'C - Spermatogenesis leads to four sperm, while oogenesis leads to one egg.'),
          OptionButton(
              text:
                  'D - Oogenesis leads to two eggs while spermatogenesis leads to one sperm.'),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(onPressed: () {}, child: const Text('PREV')),
              TextButton(onPressed: () {}, child: const Text('NEXT')),
            ],
          ),
        ],
      ),
    );
  }
}
