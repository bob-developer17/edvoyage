import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:frontend/screens/comingsoon.dart';
import 'package:frontend/screens/fiveth_may_2025_final_ui/mcq/human_anatomy.dart';

import 'package:frontend/screens/notesnew/homecard/card.dart';
import 'package:frontend/screens/notesnew/teach_content_video_sub/mcq/sub.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;

class McqMain extends StatefulWidget {
  @override
  State<McqMain> createState() => _TeachContentVideoTwoState();
}

class _TeachContentVideoTwoState extends State<McqMain> {
  final double _verticalSpacing = 20.0;
  final double _horizontalPadding = 16.0;
  final double _iconHeightFactor = 0.08;
  final double _iconWidthFactor = 0.1;
  final double _imageHeightFactor = 0.12;

  Widget _buildImageWithPadding(String assetPath, BoxFit fit,
      {VoidCallback? onTap}) {
    Widget image = Image.asset(
      assetPath,
      width: double.infinity,
      height: MediaQuery.of(context).size.height * _imageHeightFactor,
      fit: BoxFit.fill, // Try BoxFit.fill
    );

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: _horizontalPadding),
      child:
          onTap != null ? GestureDetector(onTap: onTap, child: image) : image,
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: SizedBox(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(2.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
              ),
              padding: const EdgeInsets.all(2.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/book.png',
                    height: size.height * _iconHeightFactor,
                    width: size.width * _iconWidthFactor,
                  ),
                  const SizedBox(width: 2.0),
                  Text(
                    "/ MCQ",
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Poppins',
                        color: primaryColor),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            _buildImageWithPadding(
                'assets/teach_content_video/1.png', BoxFit.fitWidth, onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => mcqsub()),
              );
            }),
            SizedBox(height: _verticalSpacing),
            _buildImageWithPadding(
                'assets/teach_content_video/2.png', BoxFit.fitWidth),
            SizedBox(height: _verticalSpacing),
            _buildImageWithPadding(
                'assets/teach_content_video/3.png', BoxFit.fitWidth),
            SizedBox(height: _verticalSpacing),
            _buildImageWithPadding(
                'assets/teach_content_video/4.png', BoxFit.fitWidth),
            SizedBox(height: _verticalSpacing),
            _buildImageWithPadding(
                'assets/teach_content_video/5.png', BoxFit.fitWidth),
            SizedBox(height: _verticalSpacing),
            _buildImageWithPadding(
                'assets/teach_content_video/4.png', BoxFit.fitWidth),
            SizedBox(height: _verticalSpacing),
            _buildImageWithPadding(
                'assets/teach_content_video/5.png', BoxFit.fitWidth),
          ],
        ),
      ),
    );
  }
}
