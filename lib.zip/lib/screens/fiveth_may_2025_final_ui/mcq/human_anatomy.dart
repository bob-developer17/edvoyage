import 'package:flutter/material.dart';

import 'package:frontend/screens/fiveth_may_2025_final_ui/mcq/last/quiz.dart';
import 'package:frontend/screens/notesnew/video_player/main.dart';

class mcqsub extends StatefulWidget {
  const mcqsub({super.key});

  @override
  State<mcqsub> createState() => _TeachContentMCQSubState();
}

class _TeachContentMCQSubState extends State<mcqsub> {
  final List<String> imagePaths = List.generate(
    10, // Generates 10 items (5 to 14)
    (index) => 'assets/teach_content/${index + 5}.png',
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset(
          'assets/logo_profile.png',
          width: 180,
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              const Text(
                "Book icon / MCQ / Human Anatomy",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              ListView.builder(
                shrinkWrap: true,
                physics:
                    const NeverScrollableScrollPhysics(), // To disable scrolling of ListView within SingleChildScrollView
                itemCount: imagePaths.length,
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => GametogenesisQuizPage(),
                        ),
                      );
                    },
                    child: Column(
                      children: [
                        Image.asset(
                          imagePaths[index],
                          fit: BoxFit.cover,
                        ),
                        const SizedBox(height: 10), // Space between images
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
