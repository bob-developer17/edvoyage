import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:frontend/screens/comingsoon.dart';
import 'package:frontend/screens/final_ui/2/2.dart';
import 'package:frontend/screens/notesnew/homecard/card.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;

class TeachContentVideo extends StatefulWidget {
  @override
  State<TeachContentVideo> createState() => _TeachContentVideoState();
}

class _TeachContentVideoState extends State<TeachContentVideo> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: SizedBox(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.asset(
                      'assets/book.png',
                      height: (size.height) * 0.03,
                      width: size.width * 0.1,
                    ),
                    const SizedBox(
                        width: 8.0), // Add some spacing between image and text
                    Text(
                      "/ Video",
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Poppins',
                          color: primaryColor),
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          HumanAnatomy()), // Replace with your widget
                );
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16.0), // Add horizontal padding
                child: Image.asset(
                  'assets/teach_content_video/1.png',
                  height: (size.height) * 0.09,
                  width: double.infinity, // Make it take full width
                  fit: BoxFit.fitWidth,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16.0), // Add horizontal padding
              child: Image.asset(
                'assets/teach_content_video/2.png',
                height: (size.height) * 0.09,
                width: double.infinity, // Make it take full width
                fit: BoxFit.fitWidth,
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16.0), // Add horizontal padding
              child: Image.asset(
                'assets/teach_content_video/3.png',
                height: (size.height) * 0.09,
                width: double.infinity, // Make it take full width
                fit: BoxFit.fitWidth,
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16.0), // Add horizontal padding
              child: Image.asset(
                'assets/teach_content_video/4.png',
                height: (size.height) * 0.09,
                width: double.infinity, // Make it take full width
                fit: BoxFit.fitWidth,
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16.0), // Add horizontal padding
              child: Image.asset(
                'assets/teach_content_video/5.png',
                height: (size.height) * 0.09,
                width: double.infinity, // Make it take full width
                fit: BoxFit.fitWidth,
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16.0), // Add horizontal padding
              child: Image.asset(
                'assets/teach_content_video/4.png',
                height: (size.height) * 0.09,
                width: double.infinity, // Make it take full width
                fit: BoxFit.fitWidth,
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16.0), // Add horizontal padding
              child: Image.asset(
                'assets/teach_content_video/5.png',
                height: (size.height) * 0.09,
                width: double.infinity, // Make it take full width
                fit: BoxFit.fitWidth,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
