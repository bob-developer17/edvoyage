import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/ARFandinfectiveendocarditis.dart';
import 'package:frontend/screens/Notes/Acyanoticheartdisease.dart';
import 'package:frontend/screens/Notes/Basigenetics.dart';
import 'package:frontend/screens/Notes/Behaviouraldisorders.dart';
import 'package:frontend/screens/Notes/Birthasphyxiaandhie.dart';
import 'package:frontend/screens/Notes/Bleedingdisorders.dart';
import 'package:frontend/screens/Notes/Commonbacterialinfections.dart';
import 'package:frontend/screens/Notes/Congenitalanomaliesofrespiratorysystem.dart';
import 'package:frontend/screens/Notes/Cyanoticcongenitalheartdefects.dart';
import 'package:frontend/screens/Notes/Developmentalmilestonesandassessment.dart';
import 'package:frontend/screens/Notes/Diabetesparathyroidandpubertaldisorders.dart';
import 'package:frontend/screens/Notes/Diarrhoea.dart';
import 'package:frontend/screens/Notes/Disordersofadrenalgland.dart';
import 'package:frontend/screens/Notes/Disordersofcarbohydratemetabolism.dart';
import 'package:frontend/screens/Notes/Disordersofgrowth.dart';
import 'package:frontend/screens/Notes/Disordersofproteinmetabolism.dart';
import 'package:frontend/screens/Notes/Geneticdisorders.dart';
import 'package:frontend/screens/Notes/Hematologicalmalignancies.dart';
import 'package:frontend/screens/Notes/Immunodeficiencydisorders.dart';
import 'package:frontend/screens/Notes/Inheritedtubulardisorders.dart';
import 'package:frontend/screens/Notes/Liverdisorders.dart';
import 'package:frontend/screens/Notes/Lyosomalstoragedisorders.dart';
import 'package:frontend/screens/Notes/Managementoflbwbabies.dart';
import 'package:frontend/screens/Notes/Marasmusandkwashiorkor.dart';
import 'package:frontend/screens/Notes/NeonatalResuscitation.dart';
import 'package:frontend/screens/Notes/Neonataljaundice.dart';
import 'package:frontend/screens/Notes/Neonatalsepsis.dart';
import 'package:frontend/screens/Notes/Neuromusculardisorders.dart';
import 'package:frontend/screens/Notes/NormalNewborn.dart';
import 'package:frontend/screens/Notes/Normalgrowth.dart';
import 'package:frontend/screens/Notes/OtherGIDisorders.dart';
import 'package:frontend/screens/Notes/Othermalignancies.dart';
import 'package:frontend/screens/Notes/Otherneurologicaldisorders.dart';
import 'package:frontend/screens/Notes/Pitutarydisorders.dart';
import 'package:frontend/screens/Notes/Pneumonia.dart';
import 'package:frontend/screens/Notes/Renalfailure.dart';
import 'package:frontend/screens/Notes/Respiratorydisorders.dart';
import 'package:frontend/screens/Notes/Rhematologicaldisorders.dart';
import 'package:frontend/screens/Notes/Routinecareandnormalobservationinnewborn.dart';
import 'package:frontend/screens/Notes/Seizuredisorders.dart';
import 'package:frontend/screens/Notes/Shock.dart';
import 'package:frontend/screens/Notes/TBandHIVinfectionsguidelines.dart';
import 'package:frontend/screens/Notes/Urinarytractinfection.dart';
import 'package:frontend/screens/Notes/Watersolublevitaminsandtraceelementdisorders.dart';
import 'package:frontend/utils/avatar.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:http/http.dart' as http;




class PediatricsHome extends StatefulWidget {
  @override
  State<PediatricsHome> createState() => _NotesSectionState();
}



class _NotesSectionState extends State<PediatricsHome> {
  @override
 
 
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.2,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Container(
          width: 200,
          height: 200,
          child: Image.asset(edvoyagelogo1),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding:  EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 1,
                      blurRadius: 1,
                      offset: const Offset(0, 1),
                    ),
                  ],
                  borderRadius: BorderRadius.circular(10.0),
                  color: secondaryColor,
                ),
                child: Padding(
                  padding:  EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidget(
                        text:"Pediatrics Notes",
                       size: 25,
                       color:Colors.white,
                      ),
                      SizedBox(height: 10),
                     TextWidget(
                        text:"In-depth notes on Pediatrics",
                        size:17,
                          color:Colors.white,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10),
             
          NotesSection(function: Normalnewborn(), text: "Normal Newborn", firstword: " N "),
SizedBox(height: 10),
SpecialNotesSection(function: Routinecareandnormalobservationinnewborn(), text1: "Routine care and normal", firstword: " R ", text2: "Observation in newborn"),
SizedBox(height: 10),

NotesSection(function: Basicgenetics(), text: "Basic genetics", firstword: " B "),
SizedBox(height: 10),
NotesSection(function: Managementoflbwbabies(), text: "Management Of LBW Babies", firstword: " M "),
SizedBox(height: 10),
NotesSection(function: NeonatalResuscitation(), text: "Neonatal Resuscitation", firstword: " N "),
SizedBox(height: 10),
NotesSection(function: Neonatalsepsis(), text: "Neonatal sepsis", firstword: " N "),
SizedBox(height: 10),
NotesSection(function: Birthasphyxiaandhie(), text: "Birth asphyxia and hie", firstword: " B "),
SizedBox(height: 10),
NotesSection(function: Respiratorydisorders(), text: "Respiratory disorders", firstword: " R "),
SizedBox(height: 10),
NotesSection(function: Neonataljaundice(), text: "neonatal jaundice", firstword: " N "),
SizedBox(height: 10),
NotesSection(function: Normalgrowth(), text: "normal growth", firstword: " N "),
SizedBox(height: 10),
NotesSection(function: Disordersofgrowth(), text: "disorders of growth", firstword: " D "),
SizedBox(height: 10),
SpecialNotesSection(function: Developmentalmilestonesandassessment(), text1: "developmental milestones", text2:"and assessment",firstword: " D "),
SizedBox(height: 10),
NotesSection(function: Behaviouraldisorders(), text: "behavioural disorders", firstword: " B "),
SizedBox(height: 10),
NotesSection(function: Marasmusandkwashiorkor(), text: "marasmus and kwashiorkor", firstword: " M "),
SizedBox(height: 10),
SpecialNotesSection(function: Watersolublevitaminsandtraceelementdisorders(), text1: "Water soluble vitamins and ",text2:"trace element disorders", firstword: " W "),

SizedBox(height: 10),
NotesSection(function: Geneticdisorders(), text: "genetic disorders", firstword: " G "),
SizedBox(height: 10),
SpecialNotesSection(function: Disordersofcarbohydratemetabolism(), text1: "disorders of carbohydrate",text2:" metabolism", firstword: " D "),
SizedBox(height: 10),
NotesSection(function: Disordersofproteinmetabolism(), text: "Disorders of protein metabolism", firstword: " D "),
SizedBox(height: 10),
NotesSection(function: Lyosomalstoragedisorders(), text: "Lyosomal storage disorders", firstword: " L "),
SizedBox(height: 10),
NotesSection(function: Commonbacterialinfections(), text: "Common bacterial infections", firstword: " C "),
SizedBox(height: 10),
NotesSection(function: TBandHIVinfectionsguidelines(), text: "TB and HIV infections : guidelines", firstword: " T "),
SizedBox(height: 10),
NotesSection(function: Diarrhoea(), text: "Diarrhoea", firstword: " D "),
SizedBox(height: 10),
NotesSection(function: OtherGIDisorders(), text: "Other GI Disorders", firstword: " O "),
SizedBox(height: 10),
NotesSection(function: Liverdisorders(), text: "Liver disorders", firstword: " L "),
SizedBox(height: 10),
SpecialNotesSection(function: Congenitalanomaliesofrespiratorysystem(), text1: "Congenital anomalies of",text2:" respiratory system", firstword: " C "),
SizedBox(height: 10),
NotesSection(function: Pneumonia(), text: "Pneumonia", firstword: " P "),
SizedBox(height: 10),
NotesSection(function: Acyanoticheartdisease(), text: "Acyanotic heart disease", firstword: " A "),
SizedBox(height: 10),
NotesSection(function: Cyanoticcongenitalheartdefects(), text: "Cyanotic congenital heart defects", firstword: " C "),
SizedBox(height: 10),
NotesSection(function: ARFandinfectiveendocarditis(), text: "ARF and infective endocarditis", firstword: " A "),
SizedBox(height: 10),
NotesSection(function: Urinarytractinfection(), text: "Urinary tract infection", firstword: " U "),
SizedBox(height: 10),
NotesSection(function: Inheritedtubulardisorders(), text: "Inherited tubular disorders", firstword: " I "),
SizedBox(height: 10),
NotesSection(function: Renalfailure(), text: "Renal failure", firstword: " R "),
SizedBox(height: 10),
NotesSection(function: Neuromusculardisorders(), text: "Neuromuscular disorders", firstword: " N "),
SizedBox(height: 10),
NotesSection(function: Seizuredisorders(), text: "Seizure disorders", firstword: " S "),
SizedBox(height: 10),
NotesSection(function: Otherneurologicaldisorders(), text: "Other neurological disorders", firstword: " O "),
SizedBox(height: 10),
NotesSection(function: Pitutarydisorders(), text: "Pitutary disorders", firstword: " P "),
SizedBox(height: 10),
NotesSection(function: Disordersofadrenalgland(), text: "disorders of adrenal gland", firstword: " D "),
SizedBox(height: 10),
SpecialNotesSection(function: Diabetesparathyroidandpubertaldisorders(), text1: "Diabetes, parathyroid and",text2:" pubertal disorders", firstword: " D "),
SizedBox(height: 10),
NotesSection(function: Hematologicalmalignancies(), text: "Hematological malignancies", firstword: " H "),
SizedBox(height: 10),
NotesSection(function: Othermalignancies(), text: "Other malignancies", firstword: " O "),
SizedBox(height: 10),
NotesSection(function: Rhematologicaldisorders(), text: "rhematological disorders", firstword: " R "),
SizedBox(height: 10),
NotesSection(function: Bleedingdisorders(), text: "Bleeding disorders", firstword: " B "),
SizedBox(height: 10),
NotesSection(function: Shock(), text: "Shock", firstword: " S "),
SizedBox(height: 10),
NotesSection(function: Immunodeficiencydisorders(), text: "Immunodeficiency disorders", firstword: " I "),

        
        
            
            ],
          ),
        ),
      ),
    );
  }
}



class NotesSection extends StatelessWidget {
  final Widget function;
  final String text;
  final String firstword;
   NotesSection({
    super.key,
    required this.function,
    required this.text,
    required this.firstword,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
     onTap: (){
       Navigator.push(
           context,
           MaterialPageRoute(
               builder: (context) => function,
         ),
       );
     },
    child:
              Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
     color: Colors.grey.withOpacity(0.5),
     spreadRadius: 1,
     blurRadius: 1,
     offset: const Offset(0, 1),
              ),
            ],
            borderRadius: BorderRadius.circular(10.0),
            color: thirdColor,
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
     Container(
       decoration: BoxDecoration(
         color: secondaryColor,
         borderRadius: BorderRadius.circular(5.0),
       ),
       child: Padding(
         padding: const EdgeInsets.all(8.0),
         child: TextWidget(
       text:firstword,
       size: 20,
       color:Colors.white,
     ),
       ),
     ),
     Container(
       decoration: BoxDecoration(
         color: thirdColor,
         borderRadius: BorderRadius.circular(20.0),
       ),
       child: Padding(
         padding: const EdgeInsets.all(8.0),
         child:  Column(
           children: [
             TextWidget(
                          text:text,
                          size: 20,
                            color:Colors.black,
                         ),
                         
           ],
         ),
       ),
     ),
              ],
            ),
          ),
        ),
    );
  }
}





class SpecialNotesSection extends StatelessWidget {
  final Widget function;
  final String text1;
  final String text2;
  final String firstword;
   SpecialNotesSection({
    super.key,
    required this.function,
    required this.text1,
    required this.firstword,
    required this.text2,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
     onTap: (){
       Navigator.push(
           context,
           MaterialPageRoute(
               builder: (context) => function,
         ),
       );
     },
    child:
              Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
     color: Colors.grey.withOpacity(0.5),
     spreadRadius: 1,
     blurRadius: 1,
     offset: const Offset(0, 1),
              ),
            ],
            borderRadius: BorderRadius.circular(10.0),
            color: thirdColor,
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
     Container(
       decoration: BoxDecoration(
         color: secondaryColor,
         borderRadius: BorderRadius.circular(5.0),
       ),
       child: Padding(
         padding: const EdgeInsets.all(8.0),
         child: TextWidget(
       text:firstword,
       size: 20,
       color:Colors.white,
     ),
       ),
     ),
     Container(
       decoration: BoxDecoration(
         color: thirdColor,
         borderRadius: BorderRadius.circular(20.0),
       ),
       child: Padding(
         padding: const EdgeInsets.all(8.0),
         child:  Column(
           children: [
             TextWidget(
                          text:text1,
                          size: 20,
                            color:Colors.black,
                         ),
                          TextWidget(
                          text:text2,
                          size: 20,
                            color:Colors.black,
                         ),
                         
           ],
         ),
       ),
     ),
              ],
            ),
          ),
        ),
    );
  }
}




class TextWidget extends StatelessWidget {
  final String text;
  final double size;
  final Color color;
   TextWidget({
    required this.text,
    required this.size,
    required this.color,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        fontSize: size,
        fontWeight: FontWeight.bold,
        color: color,
        fontFamily: 'Roboto',
      ),
    );
  }
}

