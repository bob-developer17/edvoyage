import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:frontend/_env/env.dart';
import 'package:frontend/screens/Notes/PediatricsHome.dart';
import 'package:http/http.dart' as http;

List<String> normalNewborn = [
  
];

class ImagesList {
  List<String> imageUrls;

  ImagesList({required this.imageUrls});

  factory ImagesList.fromJson(Map<String, dynamic> json) {
    return ImagesList(
      imageUrls: List<String>.from(json['image_urls']),
    );
  }
}

class Managementoflbwbabies extends StatefulWidget {
  @override
  _ImageScreenState createState() => _ImageScreenState();
}

class _ImageScreenState extends State<Managementoflbwbabies> {
  int currentIndex = 0;

  @override
  void initState() {
  
    super.initState();
    _fetchnormalNewborn();
  }
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Display Images',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Management of LBW babies'),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (context) => PediatricsHome(),
              ));
            },
          ),
        ),
        body: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Note ${currentIndex + 1}/${normalNewborn.length}',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            Expanded(
              child: PageView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: normalNewborn.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.network(normalNewborn[index]),
                  );
                },
                onPageChanged: (index) {
                  setState(() {
                    currentIndex = index;
                  });
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
  void _fetchnormalNewborn() async {
     final response = await http.post(Uri.parse(BaseUrl.getimages), body: {
      "notesname": "managementoflbwbabies",
     }
     );
      if (response.statusCode == 200) {
        print(response.body);
        Map<String, dynamic> jsonMap = jsonDecode(response.body);

  ImagesList imagesList = ImagesList.fromJson(jsonMap);
  print(imagesList.imageUrls);
        setState(() {
          normalNewborn = imagesList.imageUrls;
        });
      } else {
        throw Exception('Failed to load images');
      }
}
}