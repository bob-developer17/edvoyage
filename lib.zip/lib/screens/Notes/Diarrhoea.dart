import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';



class Diarrhoea extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ImageSlider(),
    );
  }
}

class ImageSlider extends StatelessWidget {
  final List<String> images = [
    'assets/normalnewborn1.png',
    'assets/normalnewborn2.png',
    'assets/normalnewborn3.png',
    // Add more image asset paths as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
  title: Text('Notes Images'),
  leading: IconButton(
    icon: Icon(Icons.arrow_back),
    onPressed: () {
      Navigator.of(context).pop();
    },
  ),
),

      body: CarouselSlider(
        options: CarouselOptions(
          height: MediaQuery.of(context).size.height,
          viewportFraction: 1.0,
          enlargeCenterPage: false,
          enableInfiniteScroll: false,
          initialPage: 0,
          scrollDirection: Axis.horizontal,
        ),
        items: images.map((image) {
          return Builder(
            builder: (BuildContext context) {
              return Container(
                width: MediaQuery.of(context).size.width,
                child: Image.asset(
                  image,
                  fit: BoxFit.fill,
                ),
              );
            },
          );
        }).toList(),
      ),
    );
  }
}
