import 'package:flutter/material.dart';

class two extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Center(
        child: Image.asset('assets/doctors_1-removebg-preview 1.jpg'),
      ),
    );
  }
}
