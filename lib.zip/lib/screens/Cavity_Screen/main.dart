import 'package:flutter/material.dart';
import 'package:frontend/screens/Cavity_Screen/appbar.dart';
import 'package:frontend/utils/colors/colors.dart';

import 'card1.dart';
import 'card2.dart';
import 'dropdown.dart';

class cavity_page extends StatefulWidget {
  @override
  State<cavity_page> createState() => _CavityPageState();
}

class _CavityPageState extends State<cavity_page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: White,
      appBar: CustomAppBar(),
      body: ListView(
        children: [
          DropdownEnhanced(),
        ],
      ),
    );
  }
}
