import 'package:flutter/material.dart';

class CenteredTextWidget extends StatelessWidget {
  const CenteredTextWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Your Gateway to Global Education!",
        style: TextStyle(
            color: Colors.green, fontSize: 18, fontWeight: FontWeight.bold),
        textAlign: TextAlign.center,
      ),
    );
  }
}
