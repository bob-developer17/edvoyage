import 'package:flutter/material.dart';

class CenteredImageWidget extends StatelessWidget {
  const CenteredImageWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Image.asset(
        'assets/study_abroad.png', // Ensure the image is placed inside assets
        height: 150,
        width: 150,
        fit: BoxFit.contain,
      ),
    );
  }
}
