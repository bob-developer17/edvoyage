import 'package:flutter/material.dart';

import 'bulletin_points.dart';
import 'button.dart';
import 'image_widget.dart';
import 'text.dart';

class study_abroad extends StatelessWidget {
  const study_abroad({super.key});

  @override
  Widget build(BuildContext context) {
    final double screenHeight = MediaQuery.of(context).size.height;
    final double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          "Study Abroad",
          style: TextStyle(
              color: Colors.green, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: screenHeight * 0.05),
            const CenteredImageWidget(),
            SizedBox(height: screenHeight * 0.05),
            const CenteredTextWidget(),
            SizedBox(height: screenHeight * 0.05),
            const BulletPointsWidget(),
            SizedBox(height: screenHeight * 0.05),
            const CustomButtonWidget(),
          ],
        ),
      ),
    );
  }
}
