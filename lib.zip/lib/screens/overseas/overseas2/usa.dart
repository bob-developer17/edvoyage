import 'package:flutter/material.dart';

class USAWidget extends StatelessWidget {
  const USAWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "USA Universities",
        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
      ),
    );
  }
}
