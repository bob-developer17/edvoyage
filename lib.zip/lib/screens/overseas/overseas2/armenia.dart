import 'package:flutter/material.dart';

class ArmeniaWidget extends StatelessWidget {
  const ArmeniaWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Armenia Universities",
        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
      ),
    );
  }
}
