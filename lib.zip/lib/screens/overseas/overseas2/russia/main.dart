import 'package:flutter/material.dart';
import 'card.dart';

class russia extends StatelessWidget {
  russia({super.key});

  // 📌 Dynamic List of University Data
  final List<Map<String, dynamic>> universities = [
    {
      "logo": "assets/university1.png",
      "name": "Tver State University",
      "location": "Tver, Russia",
      "ranking": "#32 in Russia",
      "tuition": "\$4,000/year",
      "programs": "Medicine, Engineering",
      "language": "English, Russian",
      "icon": "assets/external.png",
    },
    {
      "logo": "assets/university1.png",
      "name": "Moscow State University",
      "location": "Moscow, Russia",
      "ranking": "#1 in Russia",
      "tuition": "\$6,000/year",
      "programs": "Science, Business",
      "language": "English, Russian",
      "icon": "assets/external.png",
    },
    {
      "logo": "assets/university1.png",
      "name": "Harvard University",
      "location": "Cambridge, USA",
      "ranking": "#1 in USA",
      "tuition": "\$50,000/year",
      "programs": "Law, Medicine, Business",
      "language": "English",
      "icon": "assets/external.png",
    },
    {
      "logo": "assets/university1.png",
      "name": "Oxford University",
      "location": "Oxford, UK",
      "ranking": "#1 in UK",
      "tuition": "\$45,000/year",
      "programs": "Science, Philosophy",
      "language": "English",
      "icon": "assets/external.png",
    },
    {
      "logo": "assets/university1.png",
      "name": "University of Toronto",
      "location": "Toronto, Canada",
      "ranking": "#1 in Canada",
      "tuition": "\$30,000/year",
      "programs": "Engineering, AI",
      "language": "English, French",
      "icon": "assets/external.png",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title:
            const Text("Universities", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.green,
      ),
      body: ListView.builder(
        itemCount: universities.length, // 📌 Create 5 Cards dynamically
        itemBuilder: (context, index) {
          final university = universities[index]; // Get each university details
          return card(
            logo: university["logo"],
            name: university["name"],
            location: university["location"],
            ranking: university["ranking"],
            tuition: university["tuition"],
            programs: university["programs"],
            language: university["language"],
            icon: university["icon"],
          );
        },
      ),
    );
  }
}
