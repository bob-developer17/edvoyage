import 'package:flutter/material.dart';

class card extends StatelessWidget {
  final String logo;
  final String name;
  final String location;
  final String ranking;
  final String tuition;
  final String programs;
  final String language;
  final String icon;

  const card({
    super.key,
    required this.logo,
    required this.name,
    required this.location,
    required this.ranking,
    required this.tuition,
    required this.programs,
    required this.language,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Container(
      width: screenWidth * 0.9, // 90% of screen width
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              blurRadius: 8,
              spreadRadius: 2),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 🟢 First Row (Logo + University Name + Country + Icon)
          Row(
            children: [
              SizedBox(
                width: screenWidth * 0.2, // 20% width
                child: Image.asset(logo, fit: BoxFit.contain),
              ),
              SizedBox(
                width: screenWidth * 0.7, // 70% width for text
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                          color: Colors.green,
                          fontSize: 18,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(
                      location,
                      style:
                          const TextStyle(color: Colors.black54, fontSize: 14),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: screenWidth * 0.1, // 10% width for right-side icon
                child: Image.asset(icon, fit: BoxFit.contain),
              ),
            ],
          ),

          const SizedBox(height: 15), // 📏 Space between rows

          // 🔷 Second Row (4 Columns, Each with 2 Rows)
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Ranking",
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text(ranking,
                      style:
                          const TextStyle(fontSize: 14, color: Colors.black54)),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Tuition Fee",
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text(tuition,
                      style:
                          const TextStyle(fontSize: 14, color: Colors.black54)),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Programs",
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text(programs,
                      style:
                          const TextStyle(fontSize: 14, color: Colors.black54)),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Language",
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text(language,
                      style:
                          const TextStyle(fontSize: 14, color: Colors.black54)),
                ],
              ),
            ],
          ),

          const SizedBox(height: 20), // 📏 Space before button

          // 🔴 Last Row (Red Button in Center)
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 40),
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(30), // Oval shape
              ),
              child: const Text(
                "Shortlist",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
