import 'package:flutter/material.dart';

import 'armenia.dart';
import 'canada.dart';
import 'georgia.dart';
import 'russia.dart';
import 'russia/main.dart';
import 'top.dart';
import 'uk.dart';
import 'usa.dart';

class overseastwo extends StatelessWidget {
  const overseastwo({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize:
              const Size.fromHeight(120), // Adjusted height to fit TopWidget
          child: AppBar(
            backgroundColor: Colors.white,
            elevation: 2,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.green),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: const Text(
              "Study Abroad",
              style: TextStyle(
                  color: Colors.green,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            ),
            centerTitle: true,
            flexibleSpace: Padding(
              padding: const EdgeInsets.only(
                  top: 60, left: 16), // Positioning TopWidget
              child: const TopWidget(),
            ),
            bottom: const TabBar(
              isScrollable: true,
              labelColor: Colors.green,
              unselectedLabelColor: Colors.black54,
              indicatorColor: Colors.green,
              tabs: [
                Tab(text: "Russia"),
                Tab(text: "Georgia"),
                Tab(text: "Armenia"),
                Tab(text: "USA"),
                Tab(text: "Canada"),
                Tab(text: "UK"),
              ],
            ),
          ),
        ),
        body: TabBarView(
          children: [
            russia(),
            GeorgiaWidget(),
            ArmeniaWidget(),
            USAWidget(),
            CanadaWidget(),
            UKWidget(),
          ],
        ),
      ),
    );
  }
}
