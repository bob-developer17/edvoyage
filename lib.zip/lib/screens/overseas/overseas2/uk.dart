import 'package:flutter/material.dart';

class UKWidget extends StatelessWidget {
  const UKWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "UK Universities",
        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
      ),
    );
  }
}
