import 'package:flutter/material.dart';

class GeorgiaWidget extends StatelessWidget {
  const GeorgiaWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Georgia Universities",
        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
      ),
    );
  }
}
