import 'package:flutter/material.dart';

class TimeSlotGrid extends StatelessWidget {
  final List<Map<String, String>> timeSlots;

  const TimeSlotGrid({
    Key? key,
    required this.timeSlots,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Get parent size
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    // Define grid dimensions
    double gridWidth = screenWidth * 0.9; // 90% of screen width
    double gridHeight = screenHeight * 0.7; // 70% of screen height
    double spacing = gridWidth / 9 * 0.02; // 2% of grid width
    double fspacing = spacing / 9 * 0.02; // 2% of grid width

    return Center(
      child: SizedBox(
        width: gridWidth,
        height: gridHeight,
        child: GridView.builder(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(), // Fixed grid layout
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3, // 3 columns
            mainAxisSpacing: fspacing, // Vertical spacing
            crossAxisSpacing: gridWidth * 0.02, // Horizontal spacing
            childAspectRatio:
                0.9, // Adjust to keep a slightly rectangular shape
          ),
          itemCount: timeSlots.length,
          itemBuilder: (context, index) {
            return TimeSlotCard(
              time: timeSlots[index]["time"]!,
              status: timeSlots[index]["status"]!,
              statusColor:
                  timeSlots[index]["status"] == "Available" ? "green" : "grey",
            );
          },
        ),
      ),
    );
  }
}

// Widget for a single card
class TimeSlotCard extends StatelessWidget {
  final String time;
  final String status;
  final String statusColor; // 'green' or 'grey'

  const TimeSlotCard({
    Key? key,
    required this.time,
    required this.status,
    required this.statusColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        double cardHeight = constraints.maxHeight;
        return Column(
          children: [
            // Top 60% - Time Text
            Container(
              height: cardHeight * 0.4,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
                border: Border.all(color: Colors.green, width: 2),
              ),
              child: Center(
                child: Text(
                  time,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),

            // Bottom 40% - Status Text with Conditional Background
            Container(
              height: cardHeight * 0.22,
              decoration: BoxDecoration(
                color: statusColor == "green" ? Colors.green : Colors.grey,
                borderRadius:
                    BorderRadius.vertical(bottom: Radius.circular(10)),
                border: Border.all(color: Colors.green, width: 2),
              ),
              child: Center(
                child: Text(
                  status,
                  style: TextStyle(
                    fontSize: 16,
                    color: statusColor == "green" ? Colors.white : Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
