import 'package:flutter/material.dart';
import 'button.dart';
import 'custom_appbar.dart';
import 'large_card.dart';
import 'mini_card.dart';
import 'timeslot.dart'; // Importing custom appbar

class overseas_consellor extends StatelessWidget {
  const overseas_consellor({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200], // Light grey background
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(120), // Adjusted appbar height
        child: CustomAppBar(), // 🟢 Custom AppBar with title & slot booking
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            MiniCardSection(), // 🔴 3 Red Mini Cards Section
            const SizedBox(height: 20), // Spacing

            // Grey Divider
            const Divider(
              color: Colors.grey,
              thickness: 1,
              indent: 20,
              endIndent: 20,
            ),

            const SizedBox(height: 20), // Spacing
            Expanded(
              child: SingleChildScrollView(
                child: TimeSlotGrid(
                  timeSlots: [
                    {"time": "10:00 AM", "status": "Available"},
                    {"time": "10:30 AM", "status": "Booked"},
                    {"time": "11:00 AM", "status": "Available"},
                    {"time": "11:30 AM", "status": "Booked"},
                    {"time": "12:00 PM", "status": "Available"},
                    {"time": "12:30 PM", "status": "Booked"},
                    {"time": "1:00 PM", "status": "Available"},
                    {"time": "1:30 PM", "status": "Booked"},
                    {"time": "2:00 PM", "status": "Available"},
                    {"time": "2:30 PM", "status": "Booked"},
                    {"time": "3:00 PM", "status": "Available"},
                    {"time": "3:30 PM", "status": "Booked"},
                    {"time": "4:00 PM", "status": "Available"},
                    {"time": "4:30 PM", "status": "Booked"},
                    {"time": "5:00 PM", "status": "Available"},
                    {"time": "5:30 PM", "status": "Booked"},
                    {"time": "6:00 PM", "status": "Available"},
                    {"time": "6:30 PM", "status": "Booked"},
                    {"time": "7:00 PM", "status": "Available"},
                    {"time": "7:30 PM", "status": "Booked"},
                    {"time": "8:00 PM", "status": "Available"},
                  ],
                ),
              ),
            ),
            const SizedBox(height: 30), // Spacing
            ConfirmSlotButton(), // 🔴 Confirm Slot Button
          ],
        ),
      ),
    );
  }
}
