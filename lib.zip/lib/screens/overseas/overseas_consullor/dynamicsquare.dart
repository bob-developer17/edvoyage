import 'package:flutter/material.dart';

class DynamicSquareWidget extends StatelessWidget {
  final String topText;
  final String bottomText;

  const DynamicSquareWidget({
    Key? key,
    required this.topText,
    required this.bottomText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Get screen width & height
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    // Define square size as a percentage of screen size
    double squareSize = screenWidth * 0.25; // 40% of screen width (adjustable)
    double fontSizeLarge = squareSize * 0.24; // 16% of square size
    double fontSizeSmall = squareSize * 0.20; // 10% of square size

    return Container(
      width: squareSize,
      height: squareSize,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.green, width: 3),
        borderRadius:
            BorderRadius.circular(squareSize * 0.1), // Rounded corners
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              topText,
              style: TextStyle(
                  fontSize: fontSizeLarge, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: squareSize * 0.05), // Space between texts
            Text(
              bottomText,
              style: TextStyle(fontSize: fontSizeSmall, color: Colors.black54),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
