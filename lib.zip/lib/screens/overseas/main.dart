import 'package:flutter/material.dart';
import 'package:frontend/screens/overseas/beginbutton.dart';
import 'package:frontend/utils/colors/colors.dart';
import 'package:google_fonts/google_fonts.dart';

class OverseasMain extends StatelessWidget {
  const OverseasMain({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final appBarHeight = MediaQuery.of(context).size.height;
    final appBarImageHeight =
        appBarHeight * 0.9; // Example: 60% of AppBar height
    final appBarImageWidth =
        appBarImageHeight * 1.5; // Example: Width 1.5 times the height
    final bodyImageWidth =
        screenWidth * 0.8; // Images in the body take up 80% of the screen width
    const verticalSpacing = 20.0;

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: appBarHeight * 0.12,
        title: Text(
          'Study Abroad',
          style: GoogleFonts.kanit(
            // Use GoogleFonts to apply Kanit
            fontSize: 24.0, // Set the font size to 18
            fontWeight: FontWeight.w500,
            color: primaryColor,
          ),
        ),
      ),
      body: Center(
        child: Container(
          child: Column(
            children: [
              SizedBox(
                width: bodyImageWidth,
                height: appBarHeight * 0.66,
                child: Image.asset(
                  'assets/overseas/main.png', // Replace with your main image path
                  fit: BoxFit.fill,
                ),
              ),
              const SizedBox(height: verticalSpacing),
              BeginButton()
            ],
          ),
        ),
      ),
    );
  }
}
