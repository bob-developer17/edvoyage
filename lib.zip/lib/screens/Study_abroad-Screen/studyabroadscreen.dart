import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:excel/excel.dart';
import 'package:get/get.dart';
// Import necessary packages
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../_env/env.dart';
import '../../utils/avatar.dart';
import '../University_tabs/FeedTab.dart';
import '../University_tabs/GalleryTab.dart';
import '../University_tabs/aboutTab.dart';
import '../University_tabs/courses_screenTab.dart';
import '../../utils/BottomNavigation/controller.dart';
import '../../utils/colors/colors.dart';
import '../../utils/responsive.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../widgets/tver_modal.dart';
import '../WebPage/webpage.dart';

BottomNavigationController controller = Get.put(BottomNavigationController());

class UniversitHomeScreen extends StatefulWidget {
  UniversitHomeScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<UniversitHomeScreen> createState() => _UniversitHomeScreenState();
}

class _UniversitHomeScreenState extends State<UniversitHomeScreen>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;

  @override
  void initState() {
    super.initState();

    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    super.dispose();
    _tabController!.dispose();
  }

  double xOffset = 0;
  double yOffset = 0;
  double scaleFactor = 1;
  @override
  Widget build(BuildContext context) {
    final labelTextStyle = Theme.of(context)
        .textTheme
        .titleSmall!
        .copyWith(fontFamily: 'Roboto', fontSize: 8.0);
    return Obx(() {
      int index = controller.tabIndex.toInt();

      return Scaffold(
        backgroundColor: White,
        appBar: AppBar(
          backgroundColor: White,
          centerTitle: true,
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back_ios, color: Cprimary)),
          title: Container(
            width: 200, // Set the width of the container
            height: 200, // Set the height of the container
            child: Image.asset(
                edvoyagelogo1), // Replace with the actual image path
          ),
        ),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Stack(
                children: <Widget>[
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 150.0,
                    decoration: BoxDecoration(
                        color: White,
                        shape: BoxShape.rectangle,
                        image: DecorationImage(
                            image: NetworkImage(
                                'https://www.ruseducation.in/wp-content/uploads/2022/01/Siberian-State-Medical-University.webp'),
                            fit: BoxFit.cover)),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    heightFactor: 2.3,
                    child: Container(
                      alignment: Alignment.bottomCenter,
                      width: 100,
                      height: 90.0,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                            image: AssetImage('assets/images.jpg'),
                            fit: BoxFit.cover),
                      ),
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Tver State Medical University',
                          style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 21,
                              fontWeight: FontWeight.bold)),
                      hGap(5),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => GoogleScreenWidget(
                                      url: 'https://sibmed.ru/ru/')));
                        },
                        child: Image.asset(
                          "assets/external-link-alt.png",
                          width: 10,
                          height: 10,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.location_on_outlined),
                      hGap(5),
                      Text('Tver Oblast , Russia',
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            fontSize: 20,
                          )),
                    ],
                  ),
                  vGap(5),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(secondaryColor),
                            shape: MaterialStatePropertyAll(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5.0),
                                side: BorderSide(color: grey2),
                              ),
                            )),
                        onPressed: () {},
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'UnFollow',
                              style:
                                  TextStyle(fontFamily: 'Roboto', color: White),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                          ],
                        ),
                      ),
                      hGap(25),
                      ElevatedButton(
                          style: ButtonStyle(
                              backgroundColor:
                                  MaterialStateProperty.all(Ctext2),
                              shape: MaterialStatePropertyAll(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(5.0),
                                  side: BorderSide(color: grey2),
                                ),
                              )),
                          onPressed: () {
                            _launchWhatsApp('1234567890');
                          },
                          child: Image.network(
                              "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/WhatsApp_icon.png/598px-WhatsApp_icon.png",
                              width: 26.0,
                              height: 26.0)),
                      hGap(25),
                      ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor: WidgetStateProperty.all(Ctext2),
                            shape: WidgetStatePropertyAll(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5.0),
                                side: BorderSide(color: grey2),
                              ),
                            )),
                        onPressed: () {
                          displayModalBottomSheet(context);
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Apply',
                              style: TextStyle(
                                  fontFamily: 'Roboto', color: fourthColor),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                          ],
                        ),
                      ),
                    ],
                  )
                ],
              ),
              vGap(5),
              Container(
                color: White,
                child: TabBar(
                  unselectedLabelColor: Colors.grey,
                  labelColor: Cprimary,
                  controller: _tabController,
                  indicatorColor: Cprimary,
                  labelStyle: Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.copyWith(fontSize: 15.0) ??
                      TextStyle(fontSize: 15.0),
                  unselectedLabelStyle: Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.copyWith(fontSize: 14.0) ??
                      TextStyle(fontSize: 14.0),
                  indicatorSize: TabBarIndicatorSize.tab,
                  tabs: const [
                    Tab(child: Text('About')),
                    Tab(child: Text('Feed')),
                    Tab(child: Text('Courses')),
                    Tab(child: Text('Gallery')),
                  ],
                ),
              ),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    AboutTab(),
                    FeedTab(),
                    CoursesScreenTab(),
                    GalleryTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    });
  }

  void _launchWhatsApp(String phone) async {
    Uri url = Uri.parse("https://wa.me/$phone");
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  _launchURL() async {
    const url = 'https://www.google.com';
    if (await canLaunch(url)) {
      await launch(url, forceWebView: true);
    } else {
      throw 'Could not launch $url';
    }
  }
}

Future<bool> _requestStoragePermission() async {
  var status = await Permission.storage.request();
  if (status.isGranted) {
    // Permission is granted
    return true;
  } else {
    // Permission is denied
    // Handle the denial
    return false;
  }
}

void displayModalBottomSheet(context) {
  showModalBottomSheet(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30.0),
          topRight: Radius.circular(30.0),
          bottomLeft: Radius.circular(20.0),
          bottomRight: Radius.circular(20.0),
        ),
      ),
      isScrollControlled: true,
      context: context,
      builder: (BuildContext bc) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30),
              topRight: Radius.circular(30),
            ),
            color: whiteColor,
          ),
          // Adjust the height based on your needs, e.g., getHeight(context) / 2
          height: MediaQuery.of(context).size.height * 0.42,
          child: Column(
            children: [Expanded(child: DropDownDemo())],
          ),
        );
      });
}
